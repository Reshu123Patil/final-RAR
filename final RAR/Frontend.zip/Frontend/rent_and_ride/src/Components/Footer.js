import React from 'react'

const Footer = () => {
  return (
    <div className="footer">
      
      <h6>©2022 - 2025 All Rights Reserved</h6>
    </div>
  )
}

export default Footer
