export const CAR_LIST_REQUEST = "CAR_LIST_REQUEST";
export const CAR_LIST_SUCCESS = "CAR_LIST_SUCCESS";
export const CAR_LIST_FAIL = "CAR_LIST_FAIL";
export const CAR_LIST_RESET = "CAR_LIST_RESET";


